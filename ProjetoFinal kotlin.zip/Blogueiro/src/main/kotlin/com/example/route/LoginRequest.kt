package com.example.route

data class LoginRequest(
    val email: String,
    val password_hash: String
)
